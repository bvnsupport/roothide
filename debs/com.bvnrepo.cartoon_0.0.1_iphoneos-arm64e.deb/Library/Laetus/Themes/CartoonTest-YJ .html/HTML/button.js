let colors = [
    ['#AEA2C5', '#76BB68'],
    ['#F29388', '#EFBF4D'],
    ['#B22B27', '#F4BFD4'],
    ['#6CACE4', '#AEA2C5']
];

let colorIndex = 0;

// Lấy tất cả các nút có class .gradient-button
let buttons = document.querySelectorAll('.gradient-button');

buttons.forEach(button => {
    button.addEventListener('click', function() {
        let container = this.parentElement;
        let gradientEffect = container.querySelector('.gradient-effect');

        // Lấy màu từ danh sách theo thứ tự
        let currentColors = colors[colorIndex];
        colorIndex = (colorIndex + 1) % colors.length; // Vòng lặp lại khi hết danh sách

        // Áp dụng màu từ danh sách cho gradient
        gradientEffect.style.background = `radial-gradient(circle, ${currentColors[0]}, ${currentColors[1]})`;

        // Thêm lớp 'active' để hiển thị gradient
        container.classList.add('active');
        
        // Sau 1 giây, bắt đầu hiệu ứng mờ dần
        setTimeout(function() {
            container.classList.add('fade-out');
            
            // Sau khi mờ dần, loại bỏ gradient và hiển thị lại nút
            setTimeout(function() {
                container.classList.remove('active', 'fade-out');
            }, 3000); // Thời gian mờ dần là 3 giây
        }, 1000); // Hiển thị gradient trong 1 giây

        // Nếu nút đang có hiệu ứng fade out, gỡ bỏ lớp fade-out
        if (container.classList.contains('fade-out')) {
            container.classList.remove('fade-out');
        }
    });
});
